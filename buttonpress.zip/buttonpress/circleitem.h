#ifndef CIRCLEITEM_H
#define CIRCLEITEM_H

#include <QGraphicsEllipseItem>

class CircleItem : public QGraphicsEllipseItem
{
public:
    CircleItem();
};

#endif // CIRCLEITEM_H
