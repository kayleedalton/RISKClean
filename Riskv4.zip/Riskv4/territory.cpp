#include "territory.h"

Territory::Territory(int id, int owner, int troops)
    : id(id), owner(owner), troops(troops) {
    // Adjacency list will be initialized in the game setup
}
